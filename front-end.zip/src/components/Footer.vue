<template>
    <footer class="footer">
      <div class="footer-content">
        <p>&copy; 2024 African Art & craft. All rights reserved.</p>
        <ul class="footer-links">
          <li><router-link to="/">Home</router-link></li>
          <li><router-link to="/about">About</router-link></li>
          <li><router-link to="/products">Products</router-link></li>
          <li><router-link to="/contact">Contact</router-link></li>
        </ul>
      </div>
    </footer>
  </template>
  
  <script>
  import facebook from '@/assets/facebook.gif';
  
  export default {
    name: "AppFooter", // Changed component name to "AppFooter"
    data() {
      return {
        facebook: facebook,
      };
    },
  };
  </script>
  
  <style>
  .footer {
    background-color: #333;
    color: #fff;
    padding: 20px 0;
    text-align: center;
  }
  
  .footer-content {
    max-width: 1200px;
    margin: 0 auto;
  }
  
  .footer p {
    margin: 0;
  }
  
  .footer-links {
    list-style-type: none;
    padding: 0;
  }
  
  .footer-links li {
    display: inline-block;
    margin-right: 20px;
  }
  
  .footer-links li:last-child {
    margin-right: 0;
  }
  
  .footer-links a {
    color: #fff;
    text-decoration: none;
  }
  
  .footer-links a:hover {
    text-decoration: underline;
  }
  </style>
  