<template>
    <div class="nav-bar">
      <router-link to="/products" class="products-link">
        <div class="logo-wrap">
          <img :src="logo" />
        </div>
      </router-link>
      <router-link to="/cart" class="cart-link">
        <button>Shopping Cart</button>
        <button>Productst</button>
        <button>Account</button>
        <button>Profile</button>
      </router-link>
    </div>
  </template>
  
  <script>
  import logo from '@/assets/Acc.png';
  
  export default {
    name: "NavBar",
    data() {
      return {
        logo,
      }
    }
  }
  </script>