import shona from './assets/shona.webp';
import head from './assets/Head.webp';
import Carved from './assets/Carved.webp';
import Womanhead from './assets/Womanhead.webp';
import Man from './assets/Man.webp';
import Praying from './assets/praying.webp';
import Twins from './assets/Twins.webp';
import woman from './assets/woman.webp';
import Exotic from './assets/ExoticAfricanWomenSculpture.webp';
import pregnant from './assets/pregnant.webp';

export const cartItems = [
  {
    id: '123',
    name: 'Shona Man',
    price: 'R2600.00',
    imageName: shona,
  },{
    id: '234',
    name: 'Exotic African Women Sculpture',
    price: 'R2600.00',
    imageName: Exotic,
  },
  {
    id: '345',
    name: 'Carved Twin figure Ibeji Yoruba People, Nigeria',
    price: 'R4,617',
    imageName: Carved,
}] ;

export const products = [
  {
    id: '123',
    name: 'Shona Man',
    price: 'R2600.00',
    imageName: shona,
  },{
    id: '234',
    name: 'Exotic African Women Sculpture',
    price: 'R2600.00',
    imageName: Exotic,
  },
  {
    id: '345',
    name: 'Carved Twin figure Ibeji Yoruba People, Nigeria',
    price: 'R4,617',
    imageName: Carved,
  },
  {
    id: '234',
    name: 'African Wooden Sculpture',
    price: 'R3499.00',
    imageName: Man,
  },
  {
    id: '345',
    name: 'Carved Wooden African Head',
    price: 'R3200.00',
    imageName: head,
  },
  {
    id: '456',
    name: 'brass Woman head Sculpture',
    price: 'R2600.00',
    imageName: Womanhead,
  },
  {
    id: '678',
    name: 'Praying',
    price: 'R444.50',
    imageName: Praying,
  },
  {
    id: '789',
    name: 'Twin head Sculptures',
    price: 'R2400.50',
    imageName: Twins,
  },
  {
    id: '890',
    name: 'Bald',
    price: 'R240.50',
    imageName: woman,
  },
  {
    id: '909',
    name: 'African Mother',
    price: 'R240.50',
    imageName: pregnant,
  },
];
