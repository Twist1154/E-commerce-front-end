<template>
  <div>
    <NavBar />
    <h1>African Arts & Craft</h1>
    <div class="page-wrap">
      <router-view></router-view>
    </div>
    <Footer />
  </div>
</template>

<script>
import NavBar from '@/components/NavBar.vue';
import Footer from '@/components/Footer.vue'; // Corrected import statement

export default {
  name: "App",
  components: {
    NavBar,
    Footer // Registering the Footer component
  }
};
</script>